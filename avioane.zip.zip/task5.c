#include "./utils.h"

void SolveTask5(void *info, int nr_avioane, int T, int nr_pct_coord, int *X, int *Y, int N) {
    // TODO(student) : Stuff
}
